# NimbusEval Demo Trace Data

This directory contains packaged demo trace documents for testing and onboarding with NimbusEval.

## Format

Each file in `traces/` is a JSON document following the `DemoTraceDocument` schema:

```json
{
  "demo_id": "unique_identifier",
  "title": "Human-readable title",
  "description": "Detailed description",
  "tags": ["categorization", "tags"],
  "framework": "langgraph",
  "raw_trace": { "... LangGraph-shaped trace payload ..." },
  "case": {
    "case_id": "...",
    "input": "User prompt or task",
    "output": "Agent response",
    "expected_output": "Expected ideal response",
    "reference": "Ground truth reference",
    "context": "Background context",
    "retrieved_contexts": ["chunks", "..."],
    "metadata": { "demo_id": "...", "scenario_tags": [...], "expected_tools": [...] }
  }
}
```

## Usage

```python
from nimbuseval.demo import load_demo_cases, load_demo_traces

# Load all demo cases (TraceEvaluationCase objects)
cases = load_demo_cases()

# Load all traces (AgentTrace objects)
traces = load_demo_traces()

# Load a specific demo
case = load_demo_case("demo_001_customer_support")
```

See `src/nimbuseval/demo/` for the full public API.
